const serializeAddress = (a) => `${a.address1}|${a.address2}|${a.city}|${a.state}|${a.zip}`.toLowerCase();

exports = (changeEvent) => {
  /*
    A Database Trigger will always call a function with a changeEvent.
    Documentation on ChangeEvents: https://docs.mongodb.com/manual/reference/change-events/

    Access the _id of the changed document:
    const docId = changeEvent.documentKey._id;

    Access the latest version of the changed document
    (with Full Document enabled for Insert, Update, and Replace operations):
    const fullDocument = changeEvent.fullDocument;

    const updateDescription = changeEvent.updateDescription;

    See which fields were changed (if any):
    if (updateDescription) {
      const updatedFields = updateDescription.updatedFields; // A document containing updated fields
    }

    See which fields were removed (if any):
    if (updateDescription) {
      const removedFields = updateDescription.removedFields; // An array of removed fields
    }

    Functions run by Triggers are run as System users
    and have full access to Services, Functions, and MongoDB Data.

    Access a mongodb service:
    const collection = context.services.get("mongodb-atlas")
    .db("verbenergy")
    .collection("newcustomers");
    const doc = collection.findOne({ name: "mongodb" });

    Note: In Atlas Triggers, the service name is defaulted to the cluster name.

    Call other named functions if they are defined in your application:
    const result = context.functions.execute("function_name", arg1, arg2);

    Access the default http client and execute a GET request:
    const response = context.http.get({ url: <URL> })

    Learn more about http client here: https://docs.mongodb.com/realm/functions/context/#context-http
  */
  const customer = changeEvent.fullDocument;
  const customerId = changeEvent.documentKey._id;
  const collection = context.services.get('mongodb-atlas').db('verbenergy').collection('newcustomers');
  const query = { _id: customerId };
  const newAddress = customer.shippingAddress;
  newAddress._id = newAddress._id || new BSON.ObjectId();
  const serialized = serializeAddress(newAddress);
  const match = customer.addressBook?.find((a) => serializeAddress(a) === serialized);
  if (match) {
    console.log('SKIPPING, Address already exists!', serialized);
    return;
  }
  const update = {
    $push: { addressBook: { $each: [newAddress], $position: 0 } },
  };
  const options = { returnNewDocument: true };
  collection.findOneAndUpdate(query, update, options).then((result) => {
    console.log('customer: ', JSON.stringify(result));
  }).catch((err) => console.error(`${err}`));
};
